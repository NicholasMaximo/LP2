﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade1
{
    public partial class Form1 : Form
    {
        Double NumeroUm;
        Double NumeroDois;
        Double Resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtNumeroUm_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!Double.TryParse(txtNumeroUm.Text, out NumeroUm)) 
            {
                MessageBox.Show("Insira um Numero");
                txtNumeroUm.Focus();
                
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Resultado = NumeroUm + NumeroDois;
            txtResultado.Text = Resultado.ToString("N2");
        }

        private void txtNumeroDois_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!Double.TryParse(txtNumeroDois.Text, out NumeroDois))
            {
                MessageBox.Show("Insira um Numero");
                txtNumeroUm.Focus();

            }
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            Resultado = NumeroUm - NumeroDois;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if (NumeroDois != 0)
            {
                Resultado = NumeroUm * NumeroDois;
                txtResultado.Text = Resultado.ToString();
            }

            else
            {
                Resultado = 0;
                MessageBox.Show("Erro: impossivel multiplicar por zero.");
                txtNumeroDois.Focus();
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (NumeroDois != 0)
            {
                Resultado = NumeroUm / NumeroDois;
                txtResultado.Text = Resultado.ToString();
            }

            else
            {
                Resultado = 0;
                MessageBox.Show("Erro: impossivel dividir por zero.");
                txtNumeroDois.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumeroUm.Clear();
            txtNumeroDois.Clear();
            txtResultado.Clear();
        }
    }
}
