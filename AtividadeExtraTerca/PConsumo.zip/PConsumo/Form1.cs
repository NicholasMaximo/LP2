﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; // Necessário para usar a função InputBox

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double[,] dadosConsumo = new double[5, 4]; // Matriz para armazenar os dados de consumo
        string[] semanasdoMes = { "Semana 1", "Semana 2", "Semana 3", "Semana 4" }; // Array para armazenar os nomes das semanas  
        string[] nomesSetores = { "Producão", "Escritorio", "Refeitorio", "Limpeza", "Logística" }; // Array para armazenar os nomes dos setores
        string aux = "";
        double[] totalSetor = new double[5];

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            

            for (int setor = 0; setor < nomesSetores.Length; setor++)
            {

                for (int semana = 0; semana < semanasdoMes.Length; semana++)
                {
                    aux = Interaction.InputBox($"Digite o consumo de agua para o setor {nomesSetores[setor]} na {semanasdoMes[semana]}:", "Entrada de Dados");

                    if (aux == "")
                    {
                        MessageBox.Show("Insira um valor válido.");
                        return; // Sai do método para evitar continuar com dados inválidos
                    }

                    else if (!double.TryParse(aux, out dadosConsumo[setor, semana]) || dadosConsumo[setor, semana] < 0)
                    {
                        MessageBox.Show("Entrada inválida. Por favor, insira um número válido.");
                        semana--; // Decrementa para repetir a entrada para a mesma semana

                    }
                    else
                    {
                        totalSetor[setor] += dadosConsumo[setor, semana];
                    }   
                }
            }

            double totalGeral = 0;

            for (int setor = 0; setor < nomesSetores.Length; setor++)
            {
                lstbxResultado.Items.Add($"{nomesSetores[setor]}: {totalSetor[setor]:F0} L -> {totalSetor[setor] * 0.01:C2}");
                totalGeral += totalSetor[setor];
            }

            lstbxResultado.Items.Add("---------------------------------------------");
            lstbxResultado.Items.Add($"Total geral:{totalGeral:F0} L -> {totalGeral * 0.01:C2}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}