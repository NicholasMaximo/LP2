﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividadeFive
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            int n;
            double h = 0;

            if (!int.TryParse(txtNumN.Text, out n) || n <= 0)
            {
                MessageBox.Show("Digite um número válido.");
                txtNumN.Focus();
            }
            for (int i = 1; i <= n; i++)
            {
                h += 1.0 / i;
            }

            txtNumH.Text = h.ToString("F2");
        }
    }
}
