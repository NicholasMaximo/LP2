﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividadeFive
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbxSalario.Text, out double salario) || salario <= 0)
            {
                MessageBox.Show("Digite um valor de salário válido.");
                txtbxSalario.Focus();
                return;
            }

            if (!double.TryParse(txtbxProd.Text, out double producao) || producao <= 0)
            {
                MessageBox.Show("Digite um valor de produção válido.");
                txtbxProd.Focus();
                return;
            }

            if (!double.TryParse(txtbxGratifi.Text, out double gratificacao) || gratificacao < 0)
            {
                MessageBox.Show("Digite um valor de gratificação válido.");
                txtbxGratifi.Focus();
                return;
            }

            int b = producao >= 100 ? 1 : 0;
            int c = producao >= 120 ? 1 : 0;
            int d = producao >= 150 ? 1 : 0;

            double salarioBruto = salario + salario * (0.05 * b + 0.1 * c + 0.1 * d) + gratificacao;

            if (salarioBruto > 7000 && !(producao >= 150 && gratificacao > 0))
            {
                MessageBox.Show("Não atende aos critérios para o aumento.");
                salarioBruto = 7000.00;
            }

            txtbxSalBruto.Text = salarioBruto.ToString("C2");
        }
    }
}
