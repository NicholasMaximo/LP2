﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividadeFive
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnQtdEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int qtdEspacoBranco = 0;

            for (int i = 0; i < rchtxtbox1.Text.Length; i++)
            {
                if(char.IsWhiteSpace(rchtxtbox1.Text[i]))
                {
                    if (posicao == 0)
                    {
                        posicao = i + 1;
                    }

                    qtdEspacoBranco++;
                }
            }
            if (posicao > 0)
            {
                MessageBox.Show($"A posição do primeiro espaço é {posicao}, e a quantidade de espaços é {qtdEspacoBranco}.");
            }
            else
            {
                MessageBox.Show("Texto sem espaços!");
            }

        }

        private void btnNumVezesR_Click(object sender, EventArgs e)
        {
            int numVezesR = 0;

            foreach (char r in rchtxtbox1.Text)
            {
                if(char.IsLetter(r) && r == 'r' || r == 'R')
                {
                    numVezesR++;
                }
            }

            MessageBox.Show($"A letra R apareceu {numVezesR} vezes");
        }

        private void btnNumDePar_Click(object sender, EventArgs e)
        {
            int qtdDePar = 0;
            int i = 0;

            while (i < rchtxtbox1.Text.Length - 1)
            {
                if (char.IsLetter(rchtxtbox1.Text[i]) && 
                    rchtxtbox1.Text[i] == rchtxtbox1.Text[i + 1])
                {
                    qtdDePar++;
                    i += 2;
                }
                else                 
                {
                    i++;
                }
            }

            MessageBox.Show($"Quantidade de pares: {qtdDePar}");
        }
    }
}
