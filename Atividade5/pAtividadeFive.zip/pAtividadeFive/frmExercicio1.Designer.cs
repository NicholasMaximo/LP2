﻿namespace pAtividadeFive
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdEspacoBranco = new System.Windows.Forms.Button();
            this.btnNumVezesR = new System.Windows.Forms.Button();
            this.btnNumDePar = new System.Windows.Forms.Button();
            this.rchtxtbox1 = new System.Windows.Forms.RichTextBox();
            this.lblDigite = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnQtdEspacoBranco
            // 
            this.btnQtdEspacoBranco.Location = new System.Drawing.Point(117, 285);
            this.btnQtdEspacoBranco.Name = "btnQtdEspacoBranco";
            this.btnQtdEspacoBranco.Size = new System.Drawing.Size(122, 63);
            this.btnQtdEspacoBranco.TabIndex = 0;
            this.btnQtdEspacoBranco.Text = "Quantidade de Espaços em branco";
            this.btnQtdEspacoBranco.UseVisualStyleBackColor = true;
            this.btnQtdEspacoBranco.Click += new System.EventHandler(this.btnQtdEspacoBranco_Click);
            // 
            // btnNumVezesR
            // 
            this.btnNumVezesR.Location = new System.Drawing.Point(339, 285);
            this.btnNumVezesR.Name = "btnNumVezesR";
            this.btnNumVezesR.Size = new System.Drawing.Size(122, 63);
            this.btnNumVezesR.TabIndex = 1;
            this.btnNumVezesR.Text = "Número de vezes que aparece a letra R";
            this.btnNumVezesR.UseVisualStyleBackColor = true;
            this.btnNumVezesR.Click += new System.EventHandler(this.btnNumVezesR_Click);
            // 
            // btnNumDePar
            // 
            this.btnNumDePar.Location = new System.Drawing.Point(550, 285);
            this.btnNumDePar.Name = "btnNumDePar";
            this.btnNumDePar.Size = new System.Drawing.Size(122, 63);
            this.btnNumDePar.TabIndex = 2;
            this.btnNumDePar.Text = "Numero de Par de letras";
            this.btnNumDePar.UseVisualStyleBackColor = true;
            this.btnNumDePar.Click += new System.EventHandler(this.btnNumDePar_Click);
            // 
            // rchtxtbox1
            // 
            this.rchtxtbox1.Location = new System.Drawing.Point(117, 48);
            this.rchtxtbox1.Name = "rchtxtbox1";
            this.rchtxtbox1.Size = new System.Drawing.Size(555, 190);
            this.rchtxtbox1.TabIndex = 3;
            this.rchtxtbox1.Text = "";
            // 
            // lblDigite
            // 
            this.lblDigite.AutoSize = true;
            this.lblDigite.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDigite.Location = new System.Drawing.Point(178, 9);
            this.lblDigite.Name = "lblDigite";
            this.lblDigite.Size = new System.Drawing.Size(432, 20);
            this.lblDigite.TabIndex = 4;
            this.lblDigite.Text = "Digite uma frase que corresponda aos botões abaixo";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDigite);
            this.Controls.Add(this.rchtxtbox1);
            this.Controls.Add(this.btnNumDePar);
            this.Controls.Add(this.btnNumVezesR);
            this.Controls.Add(this.btnQtdEspacoBranco);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnQtdEspacoBranco;
        private System.Windows.Forms.Button btnNumVezesR;
        private System.Windows.Forms.Button btnNumDePar;
        private System.Windows.Forms.RichTextBox rchtxtbox1;
        private System.Windows.Forms.Label lblDigite;
    }
}