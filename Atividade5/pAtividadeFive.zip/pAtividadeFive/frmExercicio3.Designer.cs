﻿namespace pAtividadeFive
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPalindromo = new System.Windows.Forms.Button();
            this.txtbxEntradaPalin = new System.Windows.Forms.TextBox();
            this.lblEntradaPalindromo = new System.Windows.Forms.Label();
            this.txtbxSaidaPalin = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnPalindromo
            // 
            this.btnPalindromo.Location = new System.Drawing.Point(333, 267);
            this.btnPalindromo.Name = "btnPalindromo";
            this.btnPalindromo.Size = new System.Drawing.Size(146, 27);
            this.btnPalindromo.TabIndex = 0;
            this.btnPalindromo.Text = "Verificar se é Palíndromo";
            this.btnPalindromo.UseVisualStyleBackColor = true;
            this.btnPalindromo.Click += new System.EventHandler(this.btnPalindromo_Click);
            // 
            // txtbxEntradaPalin
            // 
            this.txtbxEntradaPalin.Location = new System.Drawing.Point(276, 113);
            this.txtbxEntradaPalin.Name = "txtbxEntradaPalin";
            this.txtbxEntradaPalin.Size = new System.Drawing.Size(259, 20);
            this.txtbxEntradaPalin.TabIndex = 1;
            // 
            // lblEntradaPalindromo
            // 
            this.lblEntradaPalindromo.AutoSize = true;
            this.lblEntradaPalindromo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradaPalindromo.Location = new System.Drawing.Point(329, 49);
            this.lblEntradaPalindromo.Name = "lblEntradaPalindromo";
            this.lblEntradaPalindromo.Size = new System.Drawing.Size(157, 20);
            this.lblEntradaPalindromo.TabIndex = 2;
            this.lblEntradaPalindromo.Text = "Insira um Palíndromo";
            // 
            // txtbxSaidaPalin
            // 
            this.txtbxSaidaPalin.Location = new System.Drawing.Point(276, 193);
            this.txtbxSaidaPalin.Name = "txtbxSaidaPalin";
            this.txtbxSaidaPalin.Size = new System.Drawing.Size(259, 20);
            this.txtbxSaidaPalin.TabIndex = 3;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbxSaidaPalin);
            this.Controls.Add(this.lblEntradaPalindromo);
            this.Controls.Add(this.txtbxEntradaPalin);
            this.Controls.Add(this.btnPalindromo);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPalindromo;
        private System.Windows.Forms.TextBox txtbxEntradaPalin;
        private System.Windows.Forms.Label lblEntradaPalindromo;
        private System.Windows.Forms.TextBox txtbxSaidaPalin;
    }
}