﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pAtividadeFive
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            if(txtbxEntradaPalin.Text.Length > 50)
            {
                MessageBox.Show("O texto não pode ter mais que 50 caracteres!");
                txtbxEntradaPalin.Focus();
                return;
            }

           string semEspaco = txtbxEntradaPalin.Text.ToUpper();

            if(semEspaco.Contains(' '))
            {
                semEspaco = semEspaco.Replace(" ", "");

            }

            bool palindromo = true;
            for (int i = 0; i < semEspaco.Length / 2; i++)
            {
                if (semEspaco[i] != semEspaco[semEspaco.Length - 1 - i])
                {
                    palindromo = false;
                    break;
                }
            }

            if (palindromo)
                txtbxSaidaPalin.Text = $"{txtbxEntradaPalin.Text.ToUpper()}  É um palíndromo!";
            else
                txtbxSaidaPalin.Text = $"{txtbxEntradaPalin.Text.ToUpper()}  Não é um palíndromo!";
        }
    }
}
