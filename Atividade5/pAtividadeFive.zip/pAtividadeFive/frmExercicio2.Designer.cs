﻿namespace pAtividadeFive
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGerarH = new System.Windows.Forms.Button();
            this.lblNumN = new System.Windows.Forms.Label();
            this.txtNumN = new System.Windows.Forms.TextBox();
            this.txtNumH = new System.Windows.Forms.TextBox();
            this.lblNumH = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGerarH
            // 
            this.btnGerarH.Location = new System.Drawing.Point(361, 268);
            this.btnGerarH.Name = "btnGerarH";
            this.btnGerarH.Size = new System.Drawing.Size(99, 61);
            this.btnGerarH.TabIndex = 0;
            this.btnGerarH.Text = "Gerar Número H";
            this.btnGerarH.UseVisualStyleBackColor = true;
            this.btnGerarH.Click += new System.EventHandler(this.btnGerarH_Click);
            // 
            // lblNumN
            // 
            this.lblNumN.AutoSize = true;
            this.lblNumN.Location = new System.Drawing.Point(242, 99);
            this.lblNumN.Name = "lblNumN";
            this.lblNumN.Size = new System.Drawing.Size(55, 13);
            this.lblNumN.TabIndex = 1;
            this.lblNumN.Text = "Número N";
            // 
            // txtNumN
            // 
            this.txtNumN.Location = new System.Drawing.Point(202, 155);
            this.txtNumN.Name = "txtNumN";
            this.txtNumN.Size = new System.Drawing.Size(136, 20);
            this.txtNumN.TabIndex = 2;
            // 
            // txtNumH
            // 
            this.txtNumH.Location = new System.Drawing.Point(477, 155);
            this.txtNumH.Name = "txtNumH";
            this.txtNumH.Size = new System.Drawing.Size(136, 20);
            this.txtNumH.TabIndex = 3;
            // 
            // lblNumH
            // 
            this.lblNumH.AutoSize = true;
            this.lblNumH.Location = new System.Drawing.Point(511, 99);
            this.lblNumH.Name = "lblNumH";
            this.lblNumH.Size = new System.Drawing.Size(55, 13);
            this.lblNumH.TabIndex = 4;
            this.lblNumH.Text = "Número H";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblNumH);
            this.Controls.Add(this.txtNumH);
            this.Controls.Add(this.txtNumN);
            this.Controls.Add(this.lblNumN);
            this.Controls.Add(this.btnGerarH);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGerarH;
        private System.Windows.Forms.Label lblNumN;
        private System.Windows.Forms.TextBox txtNumN;
        private System.Windows.Forms.TextBox txtNumH;
        private System.Windows.Forms.Label lblNumH;
    }
}