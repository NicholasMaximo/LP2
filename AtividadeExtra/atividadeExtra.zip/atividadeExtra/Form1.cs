﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace atividadeExtra
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] diasSemana = { "Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado" }; // array unidimensional para armazenar os dias da semana, para facilitar a exibição na caixa de diálogo
            double[,] valores = new double[7, 5]; // 7 dias da semana e 5 produtos, forma de declarar um array bidimensional
            double [] totalDias = new double[7]; // array unidimensional para armazenar o total de cada dia da semana, para facilitar a exibição na caixa de diálogo
            string aux = ""; // variavel auxiliar para receber o valor digitado pelo usuário, para depois converter para double e armazenar no array bidimensional
            double totalGeral = 0; // variavel para armazenar o total geral dos valores digitados, para facilitar a exibição na caixa de diálogo

            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    aux = Interaction.InputBox($"Digite o valor para o produto [{j}]: do(a) {diasSemana[i]}");

                    if (aux == "")
                    {
                        return;
                    }
                    if (double.TryParse(aux, out double valor)) // metodo para validar os valores digitados, para evitar que o programa quebre caso o usuário digite um valor inválido, como uma letra ou um símbolo, e também para validar se o valor é positivo, já que não faz sentido ter um valor negativo para um produto
                    {
                        
                        if (valor < 0)
                        {
                            MessageBox.Show("Valor inválido. Por favor, digite um valor positivo.");
                            j = j - 1; // decrementa o valor de j para que o usuário possa digitar novamente o valor para o mesmo produto, caso ele tenha digitado um valor negativo, já que não faz sentido ter um valor negativo para um produto
                        }
                        else
                        {
                            valores[i, j] = valor; // armazena o valor digitado pelo usuário no array bidimensional, na posição correspondente ao dia da semana e ao produto
                            totalDias [i] += valor; // soma o valor digitado pelo usuário ao total do dia da semana correspondente, para facilitar a exibição na caixa de diálogo
                            totalGeral += valor; //
                        }
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido. Por favor, digite um número.");
                        j = j - 1;
                    }
                }

                lstbx.Items.Add(diasSemana[i] + " " + totalDias[i].ToString("N2"));

            }
            lstbx.Items.Add($"----------");
            lstbx.Items.Add($"Total Geral: {totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbx.Items.Clear();
        }
    }
}
